<script setup lang="ts">
import ProfileStats from '@/views/apps/user/view/ProfileStats.vue'
</script>

<template>
  <ProfileStats />
</template>