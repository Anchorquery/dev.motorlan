<script setup lang="ts">
import Profile from '@/views/apps/user/view/UserProfile.vue'
</script>

<template>
  <Profile />
</template>