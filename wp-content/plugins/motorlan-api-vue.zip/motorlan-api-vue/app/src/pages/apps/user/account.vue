<script setup lang="ts">
import UserProfile from '@/views/apps/user/view/UserProfile.vue'
</script>

<template>
  <UserProfile />
</template>