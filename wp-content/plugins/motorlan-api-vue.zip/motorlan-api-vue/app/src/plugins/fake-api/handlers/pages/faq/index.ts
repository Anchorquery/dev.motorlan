export const handlerPagesFaq = []
