export interface vehicleParams{
  options: object,
}
