<template>
  <div class="demo-space-y">
    <VAlert
      color="primary"
      icon="tabler-egg-cracked"
    >
      Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi.
    </VAlert>

    <VAlert
      color="primary"
      icon="tabler-device-desktop-analytics"
      variant="tonal"
    >
      Phasellus blandit leo ut odio. Morbi mattis ullamcorper velit.
    </VAlert>

    <VAlert
      color="primary"
      icon="tabler-brand-vue"
      variant="outlined"
    >
      Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.
    </VAlert>
  </div>
</template>
