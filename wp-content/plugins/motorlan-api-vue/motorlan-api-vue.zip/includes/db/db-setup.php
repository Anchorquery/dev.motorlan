<?php

function motorlan_offers_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'motorlan_offers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        publication_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        offer_amount float NOT NULL,
        offer_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        justification TEXT,
        status ENUM('pending', 'rejected', 'accepted', 'accepted_pending_confirmation', 'confirmed', 'expired') DEFAULT 'pending' NOT NULL,
        accepted_at datetime DEFAULT NULL,
        expires_at datetime DEFAULT NULL,
        confirmed_at datetime DEFAULT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
require_once MOTORLAN_API_VUE_PATH . 'includes/db/db-migration-v1-2.php';

function motorlan_run_migrations() {
    motorlan_migrate_product_messages_v1_2();
    motorlan_migrate_purchase_messages_v1_2();
}
