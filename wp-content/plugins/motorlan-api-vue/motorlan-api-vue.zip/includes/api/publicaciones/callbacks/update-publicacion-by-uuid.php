<?php
/**
 * Callback to update a publicacion by UUID.
 *
 * @package motorlan-api-vue
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Handle the request to update a publication by its UUID.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function motorlan_update_publicacion_by_uuid(WP_REST_Request $request) {
    $uuid = $request->get_param('uuid');
    $post_id = motorlan_get_post_id_by_uuid($uuid);

    if (!$post_id) {
        return new WP_Error('not_found', 'Publicación no encontrada', ['status' => 404]);
    }

    // Security check: Only author or admin can update
    $post = get_post($post_id);
    if ($post->post_author != get_current_user_id() && !current_user_can('administrator')) {
        return new WP_Error('forbidden', 'No tienes permisos para editar esta publicación.', ['status' => 403]);
    }

    // Security check: If post is pending, only admin can update
    $current_post_status = get_post_status($post_id);
    if ($current_post_status === 'pending' && !current_user_can('administrator')) {
        return new WP_Error('forbidden', 'No puedes editar una publicación que está en revisión.', ['status' => 403]);
    }

    $params = $request->get_params();
    $files = $request->get_file_params();

    // --- Handle Text Data ---
    if (isset($params['title'])) {
        wp_update_post(['ID' => $post_id, 'post_title' => sanitize_text_field($params['title'])]);
    }

    // --- Handle Slug ---
    // Solo cambiar el slug si se envía explícitamente. No regenerar automáticamente
    // para evitar romper URLs existentes (SEO, enlaces compartidos, etc.)
    if (isset($params['slug']) && !empty($params['slug'])) {
        $current_post_obj = get_post($post_id);
        $new_slug = motorlan_make_slug_unique(sanitize_title($params['slug']), $post_id);
        if ($new_slug !== $current_post_obj->post_name) {
            wp_update_post([
                'ID' => $post_id,
                'post_name' => $new_slug,
            ]);
        }
    }
    // --- Handle Post Status ---
    // This is critical for the post to be 'published', 'draft', etc.
    if (isset($params['status'])) {
        $new_status = sanitize_text_field($params['status']);

        // Si se intenta publicar, validar/balancear stock segun reglas
        if ($new_status === 'publish') {
            // Inspeccionar si el usuario envió stock en el payload
            $payload_acf = [];
            if (isset($params['acf'])) {
                $payload_acf = is_string($params['acf']) ? json_decode($params['acf'], true) : $params['acf'];
                $payload_acf = is_array($payload_acf) ? $payload_acf : [];
            }

            $payload_has_stock = array_key_exists('stock', $payload_acf);
            $payload_stock_val = $payload_has_stock ? (int) $payload_acf['stock'] : null;

            // Leer stock actual
            $current_stock_raw = function_exists('get_field') ? get_field('stock', $post_id) : get_post_meta($post_id, 'stock', true);
            $current_stock = (int) $current_stock_raw;

            if ($payload_has_stock) {
                // Si el usuario intenta publicar con stock 0, bloquear
                if ($payload_stock_val <= 0) {
                    return new WP_Error('invalid_stock_publish', 'No se puede publicar una publicacin con stock en 0.', ['status' => 400]);
                }
            } else {
                // Si el usuario no lo cambió y el stock actual es 0, setear a 1
                if ($current_stock <= 0) {
                    if (function_exists('update_field')) {
                        update_field('stock', 1, $post_id);
                    }
                    update_post_meta($post_id, 'stock', 1);
                }
            }
        }

        // Create an array with the data to update the post
        $post_update_data = [
            'ID'          => $post_id,
            'post_status' => $new_status,
        ];

        // Update the post in the database
        wp_update_post($post_update_data);

        // Also update the ACF field for consistency in the UI
        update_field('publicar_acf', $new_status, $post_id);
    }

    // --- Handle Taxonomies ---
    $categories = isset($params['categories']) ? (is_string($params['categories']) ? json_decode($params['categories'], true) : $params['categories']) : null;
    if ($categories !== null) {
        wp_set_post_terms($post_id, $categories, 'categoria');
    }

    $tipo = isset($params['tipo']) ? (is_string($params['tipo']) ? json_decode($params['tipo'], true) : $params['tipo']) : null;
    if ($tipo !== null) {
        wp_set_post_terms($post_id, $tipo, 'tipo');
    }

    // --- Handle ACF Fields ---
    $acf_data = isset($params['acf']) ? (is_string($params['acf']) ? json_decode($params['acf'], true) : $params['acf']) : [];

    // Manejar marca personalizada: guardar como pendiente para aprobación del admin
    $is_admin = current_user_can('administrator');
    if (!empty($params['marca_custom'])) {
        $custom_brand_name = strtoupper(sanitize_text_field($params['marca_custom']));
        $existing_term = get_term_by('name', $custom_brand_name, 'marca');
        if ($existing_term) {
            $acf_data['marca'] = $existing_term->term_id;
            delete_post_meta($post_id, '_pending_brand_name');
        } elseif ($is_admin) {
            // Admin: crear la marca directamente sin necesidad de aprobación
            $new_term = wp_insert_term($custom_brand_name, 'marca');
            if (is_wp_error($new_term)) {
                return new WP_Error('brand_create_error', 'Error al crear la marca: ' . $new_term->get_error_message(), ['status' => 500]);
            }
            $acf_data['marca'] = $new_term['term_id'];
            delete_post_meta($post_id, '_pending_brand_name');
        } else {
            // Usuario normal: diferir a aprobación del admin
            update_post_meta($post_id, '_pending_brand_name', $custom_brand_name);
            $acf_data['marca'] = -1; // Valor temporal
        }
    }

    // Si marca es un valor válido (> 0), limpiar cualquier _pending_brand_name residual
    if (isset($acf_data['marca']) && is_numeric($acf_data['marca']) && (int)$acf_data['marca'] > 0) {
        delete_post_meta($post_id, '_pending_brand_name');
    }

    // --- Validate Required Fields ---
    $required_acf_fields = ['marca', 'tipo_o_referencia', 'velocidad'];
    foreach ($required_acf_fields as $field) {
        if (array_key_exists($field, $acf_data) && ($acf_data[$field] === null || $acf_data[$field] === '')) {
             return new WP_Error("missing_{$field}", "El campo {$field} es obligatorio y no puede quedar vacío.", ['status' => 400]);
        }
    }

    // Validate Potencia/Par logic if either is being updated
    $tipo_alimentacion = array_key_exists('tipo_de_alimentacion', $acf_data) ? $acf_data['tipo_de_alimentacion'] : get_field('tipo_de_alimentacion', $post_id);
    $is_ac = $tipo_alimentacion === 'ac';

    // Resolver valores: usar lo enviado, o lo guardado en BD
    $current_potencia = array_key_exists('potencia', $acf_data) ? $acf_data['potencia'] : get_field('potencia', $post_id);
    $current_par = array_key_exists('par_nominal', $acf_data) ? $acf_data['par_nominal'] : get_field('par_nominal', $post_id);

    if ($is_ac) {
        if ($current_potencia === null || $current_potencia === '' || $current_potencia === false) {
            return new WP_Error('missing_power', 'La potencia es obligatoria para motores AC.', ['status' => 400]);
        }
    } else {
        $has_potencia = $current_potencia !== null && $current_potencia !== '' && $current_potencia !== false;
        $has_par = $current_par !== null && $current_par !== '' && $current_par !== false;
        if (!$has_potencia && !$has_par) {
            return new WP_Error('missing_power_or_torque', 'Debe especificar Potencia o Par Nominal.', ['status' => 400]);
        }
    }

    $checkbox_acf_fields = ['servomotores', 'regulacion_electronica_drivers'];
    foreach ($checkbox_acf_fields as $checkbox_field) {
        if (array_key_exists($checkbox_field, $acf_data)) {
            $acf_data[$checkbox_field] = motorlan_normalize_checkbox_acf_value($post_id, $checkbox_field, $acf_data[$checkbox_field]);
        }
    }

    // --- Update ACF Fields Individually ---
    if (!empty($acf_data)) {
        if (isset($acf_data['marca'])) update_field('marca', $acf_data['marca'], $post_id);
        if (isset($acf_data['tipo_o_referencia'])) update_field('tipo_o_referencia', sanitize_text_field($acf_data['tipo_o_referencia']), $post_id);
        if (isset($acf_data['potencia'])) update_field('potencia', $acf_data['potencia'], $post_id);
        if (isset($acf_data['velocidad'])) update_field('velocidad', $acf_data['velocidad'], $post_id);
        if (isset($acf_data['par_nominal'])) update_field('par_nominal', $acf_data['par_nominal'], $post_id);
        if (isset($acf_data['voltaje'])) update_field('voltaje', $acf_data['voltaje'], $post_id);
        if (isset($acf_data['intensidad'])) update_field('intensidad', $acf_data['intensidad'], $post_id);
        if (isset($acf_data['pais'])) update_field('pais', sanitize_text_field($acf_data['pais']), $post_id);
        if (isset($acf_data['provincia'])) update_field('provincia', sanitize_text_field($acf_data['provincia']), $post_id);
        if (isset($acf_data['estado_del_articulo'])) update_field('estado_del_articulo', sanitize_text_field($acf_data['estado_del_articulo']), $post_id);
        if (isset($acf_data['informe_de_reparacion'])) update_field('informe_de_reparacion', $acf_data['informe_de_reparacion'], $post_id);
        if (isset($acf_data['descripcion'])) update_field('descripcion', sanitize_textarea_field($acf_data['descripcion']), $post_id);
        if (isset($acf_data['posibilidad_de_alquiler'])) update_field('posibilidad_de_alquiler', sanitize_text_field($acf_data['posibilidad_de_alquiler']), $post_id);
        if (isset($acf_data['tipo_de_alimentacion'])) update_field('tipo_de_alimentacion', sanitize_text_field($acf_data['tipo_de_alimentacion']), $post_id);
        if (isset($acf_data['servomotores'])) update_field('servomotores', $acf_data['servomotores'], $post_id);
        if (isset($acf_data['regulacion_electronica_drivers'])) update_field('regulacion_electronica_drivers', $acf_data['regulacion_electronica_drivers'], $post_id);
        if (isset($acf_data['precio_de_venta'])) update_field('precio_de_venta', $acf_data['precio_de_venta'], $post_id);
        if (isset($acf_data['precio_negociable'])) update_field('precio_negociable', sanitize_text_field($acf_data['precio_negociable']), $post_id);
        if (isset($acf_data['documentacion_adjunta'])) update_field('documentacion_adjunta', $acf_data['documentacion_adjunta'], $post_id);
        if (isset($acf_data['stock'])) update_field('stock', intval($acf_data['stock']), $post_id);
    }

    // --- Handle File Uploads ---
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');

    // Main Image
    if (isset($files['motor_image'])) {
        $attachment_id = media_handle_upload('motor_image', $post_id);
        if (!is_wp_error($attachment_id)) {
            update_field('motor_image', $attachment_id, $post_id);
        }
    } elseif (isset($params['motor_image_id'])) {
        update_field('motor_image', intval($params['motor_image_id']), $post_id);
    } else {
        update_field('motor_image', '', $post_id); // Remove image
    }

    // Gallery
    $gallery_ids = isset($params['motor_gallery_ids']) ? array_map('intval', explode(',', $params['motor_gallery_ids'])) : [];
    if (isset($files['motor_gallery'])) {
        $gallery_files = $files['motor_gallery'];
        $files_rearranged = [];
        if (is_array($gallery_files['name'])) {
            foreach ($gallery_files['name'] as $key => $name) {
                $files_rearranged[] = ['name' => $name, 'type' => $gallery_files['type'][$key], 'tmp_name' => $gallery_files['tmp_name'][$key], 'error' => $gallery_files['error'][$key], 'size' => $gallery_files['size'][$key]];
            }
        } else {
            $files_rearranged[] = $gallery_files;
        }
        foreach ($files_rearranged as $file) {
            $file_array = ['name' => $file['name'], 'tmp_name' => $file['tmp_name']];
            $attachment_id = media_handle_sideload($file_array, $post_id);
            if (!is_wp_error($attachment_id)) {
                $gallery_ids[] = $attachment_id;
            }
        }
    }
    update_field('motor_gallery', $gallery_ids, $post_id);

    // Additional Documentation
    $doc_ids = isset($params['documentacion_adicional_ids']) ? json_decode($params['documentacion_adicional_ids'], true) : [];
    $doc_nombres = isset($params['documentacion_adicional_nombres']) ? json_decode($params['documentacion_adicional_nombres'], true) : [];
    $uploaded_docs = [];

    // Re-associate existing docs
    foreach($doc_ids as $index => $doc) {
        $uploaded_docs[] = [
            'nombre' => sanitize_text_field($doc['nombre']),
            'archivo' => intval($doc['archivo']),
        ];
    }

    if (isset($files['documentacion_adicional_archivos'])) {
        $doc_files = $files['documentacion_adicional_archivos'];
        $files_rearranged = [];
        if (is_array($doc_files['name'])) {
             foreach ($doc_files['name'] as $key => $name) {
                $files_rearranged[] = ['name' => $name, 'type' => $doc_files['type'][$key], 'tmp_name' => $doc_files['tmp_name'][$key], 'error' => $doc_files['error'][$key], 'size' => $doc_files['size'][$key]];
            }
        } else {
            $files_rearranged[] = $doc_files;
        }

        foreach ($files_rearranged as $key => $file) {
            $file_array = ['name' => $file['name'], 'tmp_name' => $file['tmp_name']];
            $attachment_id = media_handle_sideload($file_array, $post_id);
            if (!is_wp_error($attachment_id)) {
                $uploaded_docs[] = [
                    'nombre' => sanitize_text_field($doc_nombres[$key]['nombre']),
                    'archivo' => $attachment_id,
                ];
            }
        }
    }
    update_field('documentacion_adicional', $uploaded_docs, $post_id);

    $updated_post = get_post($post_id);
    return new WP_REST_Response([
        'message' => 'Publicación actualizada correctamente',
        'slug'    => $updated_post->post_name,
    ], 200);
}
