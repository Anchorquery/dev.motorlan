<?php
/**
 * Helper functions for the Publicaciones REST API endpoints.
 *
 * @package motorlan-api-vue
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Build WP_Query arguments from request parameters for publicaciones.
 *
 * @param array $params Request parameters.
 * @return array Arguments for WP_Query.
 */
function motorlan_build_publicaciones_query_args($params) {
    $requested_status = !empty($params['status']) ? sanitize_text_field($params['status']) : null;

    $args = [
        'post_type'      => 'publicacion',
        'posts_per_page' => !empty($params['per_page']) ? absint($params['per_page']) : 10,
        'paged'          => !empty($params['page']) ? absint($params['page']) : 1,
        'post_status'    => !empty($params['post_status']) ? sanitize_text_field($params['post_status']) : 'publish',
    ];

    $meta_query = ['relation' => 'AND'];
    $tax_query = ['relation' => 'AND'];

    $stock_filter_min = isset($params['stock_min']) ? max(0, intval($params['stock_min'])) : 1;
    $should_filter_stock = $requested_status === null || $requested_status === 'publish';
    if ($should_filter_stock) {
        $meta_query[] = [
            'key'     => 'stock',
            'value'   => $stock_filter_min,
            'compare' => '>=',
            'type'    => 'NUMERIC',
        ];
    }

    $filterable_fields = [
        'marca', 'tipo_o_referencia', 'potencia', 'velocidad', 'par_nominal', 'voltaje', 'intensidad',
        'pais', 'provincia', 'posibilidad_de_alquiler',
        'servomotores', 'regulacion_electronica_drivers', 'precio_de_venta', 'precio_negociable', 'uuid','estado_del_articulo'
    ];

    // tipo_de_alimentacion: accept both new values ('ac'/'dc') and legacy ACF radio values
    if (!empty($params['tipo_de_alimentacion'])) {
        $val = sanitize_text_field($params['tipo_de_alimentacion']);
        $legacy_map = ['ac' => 'Alterna (C.A.)', 'dc' => 'Continua (C.C.)'];
        if (isset($legacy_map[$val])) {
            $meta_query[] = [
                'relation' => 'OR',
                ['key' => 'tipo_de_alimentacion', 'value' => $val, 'compare' => '='],
                ['key' => 'tipo_de_alimentacion', 'value' => $legacy_map[$val], 'compare' => '='],
            ];
        } else {
            $meta_query[] = ['key' => 'tipo_de_alimentacion', 'value' => $val, 'compare' => '='];
        }
    }

    // Helper to parse range strings like "10-50"
    $parse_range = function($value) {
        if (!is_string($value)) return null;
        $parts = array_map('trim', explode('-', $value));
        if (count($parts) !== 2) return null;
        $min = is_numeric($parts[0]) ? (float)$parts[0] : null;
        $max = is_numeric($parts[1]) ? (float)$parts[1] : null;
        if ($min === null || $max === null) return null;
        return [$min, $max];
    };

    foreach ($filterable_fields as $field) {
        if (!empty($params[$field])) {
            $raw_value = $params[$field];

            // Support numeric range filtering for specific fields
            if (in_array($field, ['par_nominal', 'velocidad', 'potencia'], true)) {
                $range = $parse_range($raw_value);
                if ($range) {
                    $meta_query[] = [
                        'key'     => $field,
                        'value'   => [$range[0], $range[1]],
                        'compare' => 'BETWEEN',
                        'type'    => 'NUMERIC',
                    ];
                    continue;
                }
            }

            if ($field === 'tipo_o_referencia') {
                // Custom handling for 'tipo_o_referencia' to ignore special characters (., -, /, spaces)
                // We strip these characters from the search term here.
                // The actual SQL modification will be handled in the query execution via posts_join/posts_where filters
                // relying on $args['motorlan_custom_search_tipo'].
                $clean_value = preg_replace('/[\.\-\/\s]/', '', $raw_value);
                if (!empty($clean_value)) {
                    $args['motorlan_custom_search_tipo'] = $clean_value;
                }
            } else {
                 $meta_query[] = [
                    'key'     => $field,
                    'value'   => sanitize_text_field($raw_value),
                    'compare' => '=',
                ];
            }
        }
    }

    if (!empty($params['status'])) {
        $meta_query[] = [
            'key'     => 'publicar_acf',
            'value'   => sanitize_text_field($params['status']),
            'compare' => '=',
        ];
    }

    if (!empty($params['category'])) {
        $tax_query[] = [
            'taxonomy' => 'categoria',
            'field'    => 'slug',
            'terms'    => array_map('sanitize_text_field', explode(',', $params['category'])),
        ];
    }

    if (!empty($params['tipo'])) {
        $tax_query[] = [
            'taxonomy' => 'tipo',
            'field'    => 'slug',
            'terms'    => array_map('sanitize_text_field', explode(',', $params['tipo'])),
        ];
    }

    if (count($meta_query) > 1) $args['meta_query'] = $meta_query;
    if (count($tax_query) > 1) $args['tax_query'] = $tax_query;

    if (!empty($params['search'])) {
        $args['s'] = sanitize_text_field($params['search']);
    }

    if (!empty($params['orderby'])) {
        $orderby = sanitize_text_field($params['orderby']);
        if ($orderby === 'price') {
            $args['meta_key'] = 'precio_de_venta';
            $args['orderby'] = 'meta_value_num';
        } else {
            $args['orderby'] = $orderby;
        }
    }

    if (!empty($params['order']) && in_array(strtoupper($params['order']), ['ASC', 'DESC'])) {
        $args['order'] = strtoupper(sanitize_text_field($params['order']));
    }

    return $args;
}

/**
 * Get all data for a single publicacion.
 *
 * @param int $post_id The post ID.
 * @return array The publicacion data.
 */
function motorlan_get_publicacion_data($post_id, $include_sensitive = false) {
    $post = get_post($post_id);
    if (!$post) return [];

    $author_id = $post->post_author;
    $user = get_userdata($author_id);

    $publicacion_item = [
        'id'           => $post_id,
        'uuid'         => get_post_meta($post_id, 'uuid', true),
        'title'        => get_the_title($post_id),
        'slug'         => $post->post_name,
        'link'         => function_exists('motorlan_get_store_url') ? motorlan_get_store_url($post_id) : get_permalink($post_id),
        'status'       => get_field('publicar_acf', $post_id),
        'author_id'    => $author_id,
        'author'       => $user ? [
            'id' => $author_id,
            'name' => $user->display_name,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'nickname' => $user->nickname,
            'user_login' => $user->user_login,
            'email' => $user->user_email,
            'avatar' => get_avatar_url($author_id),
        ] : null,
        'categories'   => motorlan_get_post_taxonomy_details($post_id, 'categoria'),
        'tipo'         => motorlan_get_post_taxonomy_details($post_id, 'tipo'),
        'acf'          => get_fields($post_id) ?: [],
        'imagen_destacada' => motorlan_format_image_for_frontend(get_field('motor_image', $post_id, true)),
    ];

    // Ocultar precio si "Consultar precio" está marcado y el usuario NO es el owner.
    // El owner siempre ve el precio como referencia ($include_sensitive = true).
    if (!$include_sensitive) {
        $consultar_precio = isset($publicacion_item['acf']['precio_negociable']) ? $publicacion_item['acf']['precio_negociable'] : 'no';
        // Normalizar valores legacy: 'Sí', 'si', 'yes', true → ocultar precio
        $is_consult = in_array($consultar_precio, ['yes', 'Sí', 'si', 'true', true], true);
        if ($is_consult && isset($publicacion_item['acf']['precio_de_venta'])) {
            unset($publicacion_item['acf']['precio_de_venta']);
        }
    }

    // Forzar la obtención de la marca si get_fields() no la incluye.
    if (empty($publicacion_item['acf']['marca'])) {
        $marca_id = get_field('marca', $post_id);
        if ($marca_id) {
            $publicacion_item['acf']['marca'] = $marca_id;
        }
    }
    
    // Enrich marca with name if it is an ID
    if (!empty($publicacion_item['acf']['marca'])) {
        $marca_val = $publicacion_item['acf']['marca'];
        if (is_numeric($marca_val) && (int) $marca_val === -1) {
            // Marca pendiente de aprobación
            $pending_brand = get_post_meta($post_id, '_pending_brand_name', true);
            if ($pending_brand) {
                $publicacion_item['marca_name'] = $pending_brand;
                $publicacion_item['pending_brand'] = $pending_brand;
            }
        } elseif (is_numeric($marca_val)) {
            $term = get_term($marca_val);
            if ($term && !is_wp_error($term)) {
                $publicacion_item['marca_name'] = $term->name;
            }
        } elseif (is_object($marca_val) && isset($marca_val->name)) {
            $publicacion_item['marca_name'] = $marca_val->name;
        } elseif (is_array($marca_val) && isset($marca_val['name'])) {
            $publicacion_item['marca_name'] = $marca_val['name'];
        } elseif (is_string($marca_val) && !is_numeric($marca_val)) {
            $publicacion_item['marca_name'] = $marca_val;
        }
    }

    return $publicacion_item;
}

/**
 * Get post taxonomy details.
 *
 * @param int    $post_id  The post ID.
 * @param string $taxonomy The taxonomy slug.
 * @return array
 */
function motorlan_get_post_taxonomy_details($post_id, $taxonomy) {
    $terms_details = [];
    $terms = wp_get_post_terms($post_id, $taxonomy);
    if (!is_wp_error($terms) && !empty($terms)) {
        foreach ($terms as $term) {
            $terms_details[] = [
                'id'   => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
            ];
        }
    }
    return $terms_details;
}

/**
 * Get post ID by UUID.
 *
 * @param string $uuid The UUID.
 * @return int|null The post ID or null if not found.
 */
function motorlan_get_post_id_by_uuid($uuid) {
    if (empty($uuid)) {
        return null;
    }
    $args = [
        'post_type'      => 'publicacion',
        'meta_key'       => 'uuid',
        'meta_value'     => $uuid,
        'posts_per_page' => 1,
        'post_status'    => 'any',
        'fields'         => 'ids',
    ];
    $query = new WP_Query($args);
    return $query->have_posts() ? $query->posts[0] : null;
}

/**
 * Normalize checkbox field values that store arrays of choices.
 *
 * When the UI sends plain booleans (true/false or 0/1) for these fields, convert
 * them into the matching choice arrays that ACF expects.
 *
 * @param int    $post_id    Post ID where the field lives.
 * @param string $field_name Field name.
 * @param mixed  $value      Incoming value.
 * @return mixed
 */
function motorlan_normalize_checkbox_acf_value($post_id, $field_name, $value) {
    if (!function_exists('get_field_object')) {
        return $value;
    }

    if (is_array($value)) {
        return $value;
    }

    if ($value === null) {
        return [];
    }

    if (is_bool($value) || in_array($value, [0, 1, '0', '1'], true)) {
        $field_object = get_field_object($field_name, $post_id);
        if (!$field_object || empty($field_object['choices'])) {
            return $value;
        }

        $choices = array_keys($field_object['choices']);
        if (empty($choices)) {
            return $value;
        }

        return (bool) $value ? [$choices[0]] : [];
    }

    return $value;
}

/**
 * Generic callback to get terms from a taxonomy.
 *
 * @param string $taxonomy The taxonomy slug.
 * @return WP_REST_Response
 */
function motorlan_get_taxonomy_terms_callback($taxonomy, $hide_empty = false) {
    $args = [
        'taxonomy'   => $taxonomy,
        'hide_empty' => $hide_empty,
    ];

    // WPML filtra automáticamente get_terms() cuando suppress_filters no está activo
    if ( has_filter( 'wpml_current_language' ) ) {
        $args['suppress_filters'] = false;
    }

    $terms = get_terms($args);
    if (is_wp_error($terms)) {
        return new WP_REST_Response(['message' => $terms->get_error_message()], 500);
    }
    return new WP_REST_Response($terms, 200);
}
/**
 * Generate a formatted slug for a publicación.
 * Format: [Nombre]-[Tipo]-[Marca]-[Referencia]-[Potencia o Par]-[Velocidad]
 *
 * @param array $data Data for the publication (title and acf).
 * @param int   $post_id Optional. Post ID to exclude from uniqueness check.
 * @return string Generated slug.
 */
function motorlan_generate_publicacion_slug($data, $post_id = 0) {
    $title = $data['title'] ?? '';
    $acf = $data['acf'] ?? [];
    $parts = [];

    // 1. Tipo (Taxonomy 'tipo')
    $tipo_id = $data['tipo'] ?? null;
    if ($tipo_id) {
        if (is_array($tipo_id)) $tipo_id = reset($tipo_id);
        $term = get_term($tipo_id, 'tipo');
        if ($term && !is_wp_error($term)) {
            $parts[] = $term->slug;
        }
    }

    // 2. Marca (ACF 'marca')
    $marca_id = $acf['marca'] ?? null;
    if ($marca_id) {
        $term = get_term($marca_id, 'marca');
        if ($term && !is_wp_error($term)) {
            $parts[] = $term->slug;
        } elseif (is_string($marca_id)) {
            $parts[] = $marca_id;
        }
    }

    // 3. Referencia (ACF 'tipo_o_referencia')
    if (!empty($acf['tipo_o_referencia'])) {
        $parts[] = $acf['tipo_o_referencia'];
    }

    // 4. Potencia o Par (ACF 'potencia' or 'par_nominal')
    if (!empty($acf['potencia'])) {
        $parts[] = $acf['potencia'] . '-kw';
    } elseif (!empty($acf['par_nominal'])) {
        $parts[] = $acf['par_nominal'] . '-nm';
    }

    // Ensure we have at least something, fallback to title if empty parts
    if (empty($parts)) {
        $parts[] = $title;
    }

    $slug = implode('-', $parts);
    $slug = sanitize_title($slug);

    // Ensure uniqueness
    return motorlan_make_slug_unique($slug, $post_id);
}

/**
 * Check if a slug already exists and return a unique version if it does.
 *
 * @param string $slug Original slug.
 * @param int    $post_id Post ID to exclude.
 * @return string Unique slug.
 */
function motorlan_make_slug_unique($slug, $post_id = 0) {
    global $wpdb;

    $check_sql = "SELECT post_name FROM $wpdb->posts WHERE post_name = %s AND post_type = 'publicacion' AND ID != %d LIMIT 1";
    $exists = $wpdb->get_var($wpdb->prepare($check_sql, $slug, $post_id));

    if (!$exists) {
        return $slug;
    }

    // If it exists, append numerical suffix
    $suffix = 2;
    while (true) {
        $alt_slug = $slug . '-' . $suffix;
        $exists = $wpdb->get_var($wpdb->prepare($check_sql, $alt_slug, $post_id));
        if (!$exists) {
            return $alt_slug;
        }
        $suffix++;
    }
}
/**
 * Generate a formatted slug based on a post ID.
 * Useful for refreshing existing posts.
 *
 * @param int $post_id The post ID.
 * @return string Generated unique slug.
 */
function motorlan_generate_slug_by_post_id($post_id) {
    if (!$post_id) return '';
    
    $post = get_post($post_id);
    if (!$post) return '';

    $data = [
        'title' => $post->post_title,
        'acf'   => get_fields($post_id) ?: [],
        'tipo'  => wp_get_post_terms($post_id, 'tipo', ['fields' => 'ids'])
    ];

    return motorlan_generate_publicacion_slug($data, $post_id);
}
