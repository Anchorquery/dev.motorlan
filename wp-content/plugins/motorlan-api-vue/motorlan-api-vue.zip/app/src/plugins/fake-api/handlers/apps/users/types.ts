export interface UserProperties {
	id: number
	fullName: string
	company: string
	role: string
	country: string
	contact: string
	email: string
	currentPlan: string
	status: string
	avatar: string
	billing: string
}
