export const handlerAppLogistics = []
