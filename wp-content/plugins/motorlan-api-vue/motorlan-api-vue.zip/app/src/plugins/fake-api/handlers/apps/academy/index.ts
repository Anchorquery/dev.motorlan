export const handlerAppsAcademy = []
