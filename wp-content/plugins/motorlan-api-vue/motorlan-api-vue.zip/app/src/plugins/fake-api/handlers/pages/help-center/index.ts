export const handlerPagesHelpCenter = []
