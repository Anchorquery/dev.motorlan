export interface ImageSizes {
  thumbnail: string
  'thumbnail-width': number
  'thumbnail-height': number
  medium: string
  'medium-width': number
  'medium-height': number
  medium_large: string
  'medium_large-width': number
  'medium_large-height': number
  large: string
  'large-width': number
  'large-height': number
  [key: string]: string | number
}

export interface ImagenDestacada {
  ID: number
  id: number
  title: string
  filename: string
  filesize: number
  url: string
  link: string
  alt: string
  author: string
  description: string
  caption: string
  name: string
  status: string
  uploaded_to: number
  date: string
  modified: string
  menu_order: number
  mime_type: string
  type: string
  subtype: string
  icon: string
  width: number
  height: number
  sizes: ImageSizes
}

export interface Publicacion {
  id: number
  title: string
  slug: string
  imagen_destacada: ImagenDestacada | null | any[]
  acf: {
    marca: string
    tipo_o_referencia: string
    precio_de_venta: number | null
    mostrar_precio: string
    [key: string]: any
  }
  marca_name?: string
  status: string
  categories: { name: string }[]
  tipo: { name: string }[]
  author: {
    id: number
    name: string
    first_name?: string
    last_name?: string
    nickname?: string
    user_login?: string
    avatar?: string
    acf: {
      calificacion: number
      ventas: number
    }
  }
}
