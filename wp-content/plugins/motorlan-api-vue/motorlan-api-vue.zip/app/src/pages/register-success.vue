<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import authV2MaskDark from '@images/pages/misc-mask-dark.png'
import authV2MaskLight from '@images/pages/misc-mask-light.png'
import { useGenerateImageVariant } from '@core/composable/useGenerateImageVariant'

const { t } = useI18n()
const authThemeMask = useGenerateImageVariant(authV2MaskLight, authV2MaskDark)

definePage({
  meta: {
    layout: 'blank',
    unauthenticatedOnly: true,
  },
})
</script>

<template>
  <VRow
    no-gutters
    class="auth-wrapper bg-surface"
  >
    <VCol
      cols="12"
      class="auth-card-v2 d-flex flex-column align-center justify-center h-screen"
      style="background: linear-gradient(to bottom right, rgb(var(--v-theme-surface)), rgba(var(--v-theme-primary), 0.05));"
    >
      <VCard
        flat
        :max-width="500"
        class="pa-6 pa-sm-8 elevation-10 rounded-xl text-center"
      >
        <VCardText>
          <VIcon
            icon="tabler-confetti"
            size="80"
            color="primary"
            class="mb-4"
          />
          <h4 class="text-h4 font-weight-bold mb-2">
            {{ t('register_success.title') }}
          </h4>
          <p class="text-body-1 text-medium-emphasis mb-6">
            {{ t('register_success.subtitle') }}
          </p>

          <VAlert
            color="info"
            variant="tonal"
            class="mb-6 rounded-lg text-start"
            icon="tabler-mail"
          >
            <div class="font-weight-bold mb-1">{{ t('register_success.verify_email') }}</div>
            <div>
              {{ t('register_success.verify_email_body') }}
            </div>
          </VAlert>

          <p class="text-body-2 text-medium-emphasis mb-6">
            {{ t('register_success.spam_note') }}
          </p>

          <VBtn
            block
            color="primary"
            size="large"
            rounded="lg"
            :to="{ name: 'login' }"
            class="font-weight-bold"
          >
            {{ t('register_success.back_to_login') }}
          </VBtn>
        </VCardText>
      </VCard>
    </VCol>
  </VRow>
</template>

<style lang="scss">
@use "@core/scss/template/pages/page-auth.scss";
</style>
