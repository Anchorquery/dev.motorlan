<script setup lang="ts">
import { ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import type { ImagenDestacada } from '@/interfaces/publicacion'
import { useApi } from '@/composables/useApi'
import { createUrl } from '@/@core/composable/createUrl'
import { useMotorFormatter } from '@/composables/useMotorFormatter'

const { t } = useI18n()
const { formatMotorName } = useMotorFormatter()
const headers = computed(() => [
  { title: t('purchases_opinions.publication'), key: 'publicacion' },
  { title: t('purchases_opinions.rating'), key: 'valoracion' },
  { title: t('purchases_opinions.comment'), key: 'comentario' },
])

const searchQuery = ref('')
const selectedRows = ref([])

// Data table options
const itemsPerPage = ref(10)
const page = ref(1)
const sortBy = ref()
const orderBy = ref()

// Update data table options
const updateOptions = (options: any) => {
  page.value = options.page
  sortBy.value = options.sortBy[0]?.key
  orderBy.value = options.sortBy[0]?.order
}

const { data: opinionsData, execute: fetchOpinions } = await useApi<any>(createUrl('/wp-json/motorlan/v1/purchases/opinions', {
  query: {
    page,
    per_page: itemsPerPage,
    orderby: sortBy,
    order: orderBy,
    search: searchQuery,
  },
}))

const opinions = computed(() => opinionsData.value?.data || [])
const totalOpinions = computed(() => opinionsData.value?.pagination.total || 0)

const getImageBySize = (image: any, size = 'thumbnail'): string => {
  if (!image)
    return ''
  if (typeof image === 'string')
    return image
  let imageObj: ImagenDestacada | null = null
  if (Array.isArray(image) && image.length > 0)
    imageObj = image[0]
  else if (image && !Array.isArray(image))
    imageObj = image as ImagenDestacada
  if (!imageObj)
    return ''
  if (imageObj.sizes && imageObj.sizes[size])
    return imageObj.sizes[size] as string
  return imageObj.url || ''
}
</script>

<template>
  <Suspense>
    <VCard
      id="opinion-list"
      class="motor-card-enhanced"
    >
      <VCardTitle class="pa-6 pb-0">
        <span class="text-h5 text-premium-title">{{ t('dashboard_lists.my_opinions') }}</span>
      </VCardTitle>
      <VCardText class="pa-6">
        <div class="dash-simple-toolbar d-flex flex-wrap gap-4">
          <div class="d-flex align-center dash-simple-toolbar__search">
            <!-- 👉 Search  -->
            <AppTextField
              v-model="searchQuery"
              :placeholder="t('dashboard_lists.search_opinion')"
              style="inline-size: 260px;"
              class="me-3"
              prepend-inner-icon="tabler-search"
            />
          </div>

          <VSpacer />
          <div class="d-flex gap-4 flex-wrap align-center dash-simple-toolbar__per-page">
            <AppSelect
              v-model="itemsPerPage"
              :items="[5, 10, 20, 25, 50]"
              style="inline-size: 80px;"
            />
          </div>
        </div>
      </VCardText>

      <VDivider />

      <!-- 👉 Datatable  -->
      <div class="table-responsive-shell">
      <VDataTableServer
        v-model:items-per-page="itemsPerPage"
        v-model:page="page"
        :headers="headers"
        :items="opinions"
        :items-length="totalOpinions"
        class="text-no-wrap pb-4"
        @update:options="updateOptions"
      >
        <!-- publicacion -->
        <template #item.publicacion="{ item }: { item: any }">
          <div class="d-flex align-center gap-x-4 py-3">
            <VAvatar
              v-if="item.raw.publicacion?.imagen_destacada"
              size="44"
              variant="tonal"
              rounded
              class="border"
              :image="getImageBySize(item.raw.publicacion.imagen_destacada, 'thumbnail')"
            />
            <div class="d-flex flex-column">
              <NuxtLink :to="`/dashboard/publications/publication/edit/${item.raw.publicacion.uuid}`">
                <span class="text-body-1 font-weight-medium text-premium-title cursor-pointer">{{ formatMotorName(item.raw.publicacion) }}</span>
              </NuxtLink>
              <span class="text-body-2 text-muted">{{ item.raw.publicacion.acf.marca.name }}</span>
            </div>
          </div>
        </template>

        <!-- valoracion -->
        <template #item.valoracion="{ item }: { item: any }">
          <VRating
            :model-value="item.raw.valoracion"
            readonly
            color="warning"
            density="compact"
            size="small"
          />
        </template>

        <!-- comentario -->
        <template #item.comentario="{ item }: { item: any }">
          <span class="text-body-2 text-high-emphasis">{{ item.raw.comentario }}</span>
        </template>

        <!-- pagination -->
        <template #bottom>
          <VDivider />
          <TablePagination
            v-model:page="page"
            :items-per-page="itemsPerPage"
            :total-items="totalOpinions"
            class="pa-4"
          />
        </template>
      </VDataTableServer>
      </div>
    </VCard>
    <template #fallback>
      <div>
        Cargando...
      </div>
    </template>
  </Suspense>
</template>

<style scoped>
.table-responsive-shell {
  overflow-x: auto;
  width: 100%;
  -webkit-overflow-scrolling: touch;
}

@media (max-width: 959px) {
  .dash-simple-toolbar {
    flex-direction: column;
    gap: 0.75rem !important;
  }

  .dash-simple-toolbar :deep(.v-spacer) {
    display: none !important;
  }

  .dash-simple-toolbar__search,
  .dash-simple-toolbar__per-page {
    width: 100%;
  }

  .dash-simple-toolbar__search :deep(.v-field),
  .dash-simple-toolbar__search :deep(.v-input),
  .dash-simple-toolbar__search :deep(.v-text-field) {
    inline-size: 100% !important;
    max-width: 100% !important;
  }

  .dash-simple-toolbar__per-page :deep(.v-field),
  .dash-simple-toolbar__per-page :deep(.v-input),
  .dash-simple-toolbar__per-page :deep(.v-select) {
    inline-size: 100% !important;
    max-width: 100% !important;
  }
}
</style>
