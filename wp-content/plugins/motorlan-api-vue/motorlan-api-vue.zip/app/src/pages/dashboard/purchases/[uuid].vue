<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { createUrl } from '@/@core/composable/createUrl'
import { useApi } from '@/composables/useApi'
import type { Publicacion } from '@/interfaces/publicacion'
import { useUserStore } from '@/@core/stores/user'
import ChatModal from '@/components/ChatModal.vue'
import { useMotorFormatter } from '@/composables/useMotorFormatter'
import { useCountries } from '@/composables/useCountries'
import RatingModal from '@/components/RatingModal.vue'
import { storeUrl } from '@/utils/urls'

const route = useRoute()
const { t } = useI18n()
const uuid = route.params.uuid as string
const { formatMotorName } = useMotorFormatter()
const { getCountryName, fetchCountries } = useCountries()

const showRatingModal = ref(false)

const handleRatingSuccess = () => {
    fetchPurchase()
}

const purchase = ref()
const isPurchaseLoading = ref(true)
const purchaseError = ref<string | null>(null)
const fetchPurchase = async () => {
  isPurchaseLoading.value = true
  purchaseError.value = null

  try {
    const request = useApi<any>(createUrl(`/wp-json/motorlan/v1/purchases/${uuid}`), { immediate: false }).get().json()
    await request.execute()

    if (request.error.value) {
      throw new Error(request.error.value.message || 'Error fetching purchase')
    }

    purchase.value = request.data.value?.data
  } catch (err: any) {
    purchase.value = undefined
    purchaseError.value = err?.message || 'Ocurrió un error al consultar la compra.'
  } finally {
    isPurchaseLoading.value = false
  }
}




onMounted(() => {
  fetchCountries()
  if (uuid) fetchPurchase()
  if (route.query.openChat === 'true') {
     isChatModalOpen.value = true
  }
})

// Current user + derived viewer role and publication data
const userStore = useUserStore()
const publication = computed<Publicacion | null>(() => {
  const pub = (purchase.value?.publicacion ?? purchase.value?.motor) as Publicacion | undefined
  return pub ?? null
})

const viewerRole = computed<'buyer' | 'seller'>(() => {
  const raw = String(purchase.value?.viewer_role || '').toLowerCase()
  if (raw === 'buyer' || raw === 'seller') return raw as 'buyer' | 'seller'

  const currentId = userStore.getUser?.id ?? null
  const sellerId = Number((purchase.value?.vendedor_id ?? publication.value?.author) || 0) || null
  if (currentId && sellerId && currentId === sellerId) return 'seller'
  return 'buyer'
})

const isBuyer = computed(() => viewerRole.value === 'buyer')
const isSeller = computed(() => viewerRole.value === 'seller')

// Normalize basic user data coming from API
type BasicUser = { id: number | null; name: string | null; email: string | null; avatar?: string | null }
const normalizeUser = (input: any): BasicUser => {
  if (!input) return { id: null, name: null, email: null, avatar: null }
  if (typeof input === 'number') return { id: input || null, name: null, email: null, avatar: null }
  const id = Number(input?.ID ?? input?.id ?? 0) || null
  const name =
    (typeof input?.display_name === 'string' && input.display_name) ? input.display_name :
    (typeof input?.name === 'string' && input.name) ? input.name :
    (typeof input?.user_nicename === 'string' && input.user_nicename) ? input.user_nicename :
    null
  const email =
    (typeof input?.user_email === 'string' && input.user_email) ? input.user_email :
    (typeof input?.email === 'string' && input.email) ? input.email :
    null
  const avatar = typeof input?.avatar === 'string' ? input.avatar : null
  return { id, name, email, avatar }
}

const sellerInfo = computed<BasicUser>(() => normalizeUser(publication.value?.author))
const buyerInfo = computed<BasicUser>(() => normalizeUser(purchase.value?.comprador ?? purchase.value?.comprador_id))
const partyTitle = computed(() => (isBuyer.value ? 'Datos del vendedor' : 'Datos del comprador'))
const partyInfo = computed<BasicUser>(() => (isBuyer.value ? sellerInfo.value : buyerInfo.value))
const partyName = computed(() => partyInfo.value.name || (isBuyer.value ? 'Vendedor' : 'Comprador'))
const partyAvatar = computed(() => partyInfo.value.avatar || null)
const partyInitials = computed(() => {
  const parts = (partyName.value || '').split(' ').filter(Boolean)
  const initials = parts.slice(0, 2).map((part: string) => part[0]?.toUpperCase()).join('')
  return initials || (isBuyer.value ? 'V' : 'C')
})
const partyEmail = computed(() => (partyInfo.value.email ? String(partyInfo.value.email) : null))
const partyHasContact = computed(() => Boolean(partyEmail.value))

const opinion = ref({ rating: 0, comment: '' })
const isSubmittingOpinion = ref(false)
const opinionSuccess = ref(false)
const opinionError = ref<string | null>(null)

const motorAcf = computed(() => (publication.value?.acf || {}) as Record<string, any>)
const sellerAcf = computed(() => (purchase.value?.motor?.author?.acf || {}) as Record<string, any>)

// Usa el composable centralizado para formatear el nombre
const productTitle = computed(() => {
  const motor = publication.value as Publicacion | null | undefined
  if (motor) {
    const formatted = formatMotorName(motor)
    if (formatted) return formatted
  }

  if (purchase.value?.title)
    return String(purchase.value.title).toUpperCase()

  return 'PRODUCTO'
})

const productTypeLabel = computed(() => {
  const types: string[] = []

  const pushCandidate = (candidate: unknown) => {
    if (!candidate)
      return

    if (typeof candidate === 'string') {
      types.push(candidate)
      return
    }

    if (Array.isArray(candidate)) {
      candidate.forEach(inner => pushCandidate(inner))
      return
    }

    if (typeof candidate === 'object') {
      const name = (candidate as Record<string, any>).name || (candidate as Record<string, any>).label
      if (name)
        types.push(String(name))
    }
  }

  const motor = publication.value as Publicacion | null | undefined

  if (Array.isArray(motor?.tipo)) {
    motor?.tipo.forEach(typeItem => pushCandidate(typeItem))
  }

  pushCandidate(motorAcf.value.tipo)
  pushCandidate(motorAcf.value.tipo_producto)

  const normalized = types
    .map(name => name.trim())
    .filter(Boolean)

  const match = (keyword: string) => normalized.find(name => name.toLowerCase().includes(keyword))

  if (match('regulador'))
    return 'Regulador'
  if (match('repuesto'))
    return 'Repuesto'
  if (match('motor'))
    return 'Motor'

  return normalized[0] || null
})
const productImage = computed(() => {
  const image = publication.value?.imagen_destacada as any
  if (!image)
    return null
  if (typeof image === 'string')
    return image
  if (Array.isArray(image))
    return image[0]?.url || null
  return image.url || null
})

const productSlug = computed(() => publication.value?.slug)
const productLink = computed(() => {
  if (!productSlug.value)
    return null

  // URL absoluta para navegación cross-base (desde mi-cuenta a la tienda)
  return storeUrl(productSlug.value)
})

const locationLabel = computed(() => {
  const country = getCountryName(motorAcf.value.pais)
  const province = motorAcf.value.provincia

  if (country && province)
    return `${province}, ${country}`

  return country || province || null
})

const sellerCompany = computed(() => {
  const company = sellerAcf.value.empresa ?? sellerAcf.value.company
  return company ? String(company) : null
})

const sellerRating = computed(() => {
  const rating = Number(sellerAcf.value.calificacion ?? sellerAcf.value.rating)
  return Number.isFinite(rating) ? rating : null
})

const sellerRatingLabel = computed(() => {
  if (sellerRating.value === null)
    return null

  return sellerRating.value.toFixed(1)
})

const sellerSales = computed(() => {
  const sales = Number(sellerAcf.value.ventas ?? sellerAcf.value.sales)
  return Number.isFinite(sales) ? sales : null
})

const sellerSalesLabel = computed(() => {
  if (sellerSales.value === null)
    return null

  return new Intl.NumberFormat('es-ES').format(sellerSales.value)
})

const sellerSalesText = computed(() => {
  if (sellerSales.value === null)
    return null

  const label = sellerSalesLabel.value ?? String(sellerSales.value)
  return `${label} ${sellerSales.value === 1 ? 'venta' : 'ventas'}`
})

const sellerPhone = computed(() => {
  const phone = sellerAcf.value.telefono ?? sellerAcf.value.phone
  return phone ? String(phone) : null
})

const sellerWhatsapp = computed(() => {
  const whatsapp = sellerAcf.value.whatsapp ?? sellerAcf.value.whatsapp_number
  return whatsapp ? String(whatsapp) : null
})

const sellerEmail = computed(() => {
  const authorEmail = purchase.value?.motor?.author?.email
  const fallbackEmail = sellerAcf.value.email
  const resolved = authorEmail || fallbackEmail

  return resolved ? String(resolved) : null
})

const sellerHasContact = computed(() => Boolean(sellerPhone.value || sellerWhatsapp.value || sellerEmail.value))

const normalizePhone = (value: string) => value.replace(/[^\d+]/g, '')

const sellerPhoneHref = computed(() => {
  if (!sellerPhone.value)
    return null

  const normalized = normalizePhone(sellerPhone.value)
  return normalized ? `tel:${normalized}` : null
})

const sellerWhatsappHref = computed(() => {
  if (!sellerWhatsapp.value)
    return null

  const normalized = normalizePhone(sellerWhatsapp.value).replace(/^\+/, '')
  return normalized ? `https://wa.me/${normalized}` : null
})

const hasSellerMetrics = computed(() => sellerRating.value !== null || sellerSalesLabel.value !== null)

const isChatModalOpen = ref(false)
const openChat = () => {
  isChatModalOpen.value = true
}

const quantityValue = computed(() => {
  const raw = (purchase.value as any)?.cantidad ?? (purchase.value as any)?.quantity ?? 1
  const qty = Number(raw) || 1
  return qty > 0 ? qty : 1
})

const quantityLabel = computed(() => {
  const qty = quantityValue.value

  return `${qty} ${qty === 1 ? 'unidad' : 'unidades'}`
})

import { formatCurrency } from '@/utils/formatCurrency'

const toNumericValue = (value: unknown): number | null => {
  if (typeof value === 'number' && Number.isFinite(value))
    return value

  if (typeof value === 'string') {
    const normalized = value.replace(/[^\d,.-]/g, '').replace(/\./g, '').replace(',', '.')
    const parsed = Number(normalized)
    if (!Number.isNaN(parsed))
      return parsed
  }

  return null
}

const formatStatusLabel = (status: string) => status
  .split(/[_-]/g)
  .filter(Boolean)
  .map(part => part.charAt(0).toUpperCase() + part.slice(1))
  .join(' ')

const offerDetails = computed(() => purchase.value?.offer ?? null)
const hasOffer = computed(() => Boolean(offerDetails.value))

const offerAmountValue = computed(() => toNumericValue((offerDetails.value as any)?.offer_amount))
const offerAmountLabel = computed(() => (offerAmountValue.value !== null ? formatCurrency(offerAmountValue.value) : null))

const publishedPriceValue = computed(() => {
  const fromPurchase = toNumericValue((purchase.value as any)?.precio_publicado)
  if (fromPurchase !== null)
    return fromPurchase

  return toNumericValue(motorAcf.value.precio_de_venta)
})

const publishedPriceLabel = computed(() => (publishedPriceValue.value !== null ? formatCurrency(publishedPriceValue.value) : null))

const purchaseTotalValue = computed(() => {
  const purchaseAmount = toNumericValue((purchase.value as any)?.precio_compra)
  if (purchaseAmount !== null)
    return purchaseAmount

  if (offerAmountValue.value !== null)
    return offerAmountValue.value

  if (publishedPriceValue.value !== null)
    return publishedPriceValue.value * quantityValue.value

  return null
})

const unitPriceValue = computed(() => {
  if (purchaseTotalValue.value !== null) {
    const qty = quantityValue.value || 1
    return purchaseTotalValue.value / qty
  }

  return publishedPriceValue.value
})

const unitPriceLabel = computed(() => {
  if (unitPriceValue.value !== null)
    return formatCurrency(unitPriceValue.value) || 'Consultar precio'

  return 'Consultar precio'
})

const totalPriceLabel = computed(() => {
  if (purchaseTotalValue.value !== null)
    return formatCurrency(purchaseTotalValue.value) || unitPriceLabel.value

  if (unitPriceValue.value !== null) {
    const total = unitPriceValue.value * quantityValue.value
    return formatCurrency(total) || unitPriceLabel.value
  }

  return 'Consultar precio'
})

const summaryPriceNotes = computed(() => {
  const notes: string[] = []

  if (quantityValue.value > 1) {
    if (unitPriceValue.value !== null) {
      const unitLabel = formatCurrency(unitPriceValue.value) || ''
      notes.push(`${quantityLabel.value} · ${unitLabel} c/u`.trim())
    }
    else {
      notes.push(quantityLabel.value)
    }
  }

  if (publishedPriceValue.value !== null && unitPriceValue.value !== null) {
    const published = publishedPriceValue.value
    if (Math.abs(unitPriceValue.value - published) > 0.009) {
      const publishedLabel = formatCurrency(published)
      if (publishedLabel)
        notes.push(`Precio publicado: ${publishedLabel}`)
    }
  }

  return notes
})

const formatDateTime = (value: string | null | undefined) => {
  if (!value)
    return null

  const normalized = value.includes('T') ? value : value.replace(' ', 'T')
  const date = new Date(normalized)

  if (Number.isNaN(date.getTime()))
    return value

  return new Intl.DateTimeFormat('es-ES', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date)
}

const offerDateLabel = computed(() => formatDateTime((offerDetails.value as any)?.offer_date))
const offerAcceptedLabel = computed(() => formatDateTime((offerDetails.value as any)?.accepted_at))
const offerConfirmedLabel = computed(() => formatDateTime((offerDetails.value as any)?.confirmed_at))
const offerExpiresLabel = computed(() => formatDateTime((offerDetails.value as any)?.expires_at))

const offerStatusInfo = computed(() => {
  const status = String((offerDetails.value as any)?.status || '').toLowerCase()
  if (!status)
    return null

  const map: Record<string, { label: string; color: 'success' | 'warning' | 'info' | 'error'; description?: string }> = {
    pending: {
      label: 'Pendiente',
      color: 'warning',
      description: 'El vendedor aun no responde a la oferta.',
    },
    accepted_pending_confirmation: {
      label: 'Aceptada por confirmar',
      color: 'info',
      description: 'La oferta fue aceptada. Queda pendiente tu confirmacion de compra.',
    },
    confirmed: {
      label: 'Confirmada',
      color: 'success',
      description: 'La oferta se confirmo y se registro la compra.',
    },
    rejected: {
      label: 'Rechazada',
      color: 'error',
      description: 'El vendedor rechazo esta oferta.',
    },
    expired: {
      label: 'Expirada',
      color: 'warning',
      description: 'La oferta vencio sin confirmacion.',
    },
  }

  const fallback = {
    label: formatStatusLabel(status),
    color: 'info' as const,
  }

  return map[status] || fallback
})

const offerJustification = computed(() => {
  const justification = (offerDetails.value as any)?.justification
  if (typeof justification === 'string' && justification.trim())
    return justification.trim()
  return null
})

const isNegotiable = computed(() => {
  const negotiable = motorAcf.value.precio_negociable

  if (typeof negotiable === 'string') {
    const normalized = negotiable.trim().toLowerCase()
    return normalized === 'si' || normalized === 'yes' || normalized === 'true'
  }

  return Boolean(negotiable)
})

const purchaseModeLabel = computed(() => {
  if (hasOffer.value)
    return 'Compra por oferta'

  return isNegotiable.value ? 'Consultar precio' : 'Compra directa'
})

const purchaseModeDescription = computed(() => {
  if (hasOffer.value) {
    if (offerAmountLabel.value)
      return `Compra concretada mediante una oferta aceptada por ${offerAmountLabel.value}.`

    return 'Compra concretada mediante una oferta aceptada.'
  }

  return isNegotiable.value
    ? 'El precio de este artículo es bajo consulta. Contacta con el vendedor para acordar el precio.'
    : 'Compra realizada al precio publicado sin negociacion.'
})

const statusRawLabel = computed(() => {
  const raw = purchase.value?.estado
  if (typeof raw !== 'string' || raw.trim() === '')
    return null

  return formatStatusLabel(raw)
})

const statusInfo = computed(() => {
  const rawStatus = typeof purchase.value?.estado === 'string' ? purchase.value.estado : ''
  const status = rawStatus.toLowerCase()
  const date = purchase.value?.fecha_compra
  const withDate = (text: string) => (date ? `El ${date} ${text}` : text)

  const map: Record<string, { label: string; title: string; description: string; tone: 'success' | 'warning' | 'info' | 'error' }> = {
    entregado: {
      label: 'Entregado',
      title: 'Recibiste la compra',
      description: withDate('confirmamos que ya la tienes.'),
      tone: 'success',
    },
    enviado: {
      label: 'Enviado',
      title: 'Tu compra va en camino',
      description: withDate('salio a entrega.'),
      tone: 'info',
    },
    en_proceso: {
      label: 'En proceso',
      title: 'Estamos preparando tu compra',
      description: withDate('estamos gestionando el envio.'),
      tone: 'info',
    },
    pendiente: {
      label: 'Venta Registrada',
      title: 'Acuerdo pendiente',
      description: withDate('Coordina el pago y la entrega directamente con el vendedor.'),
      tone: 'warning',
    },
    cancelado: {
      label: 'Cancelado',
      title: 'La compra se cancelo',
      description: withDate('anulamos el pedido.'),
      tone: 'error',
    },
  }

  if (map[status])
    return map[status]

  const fallbackLabel = statusRawLabel.value || 'En progreso'

  return {
    label: fallbackLabel,
    title: `Estado: ${fallbackLabel}`,
    description: withDate('seguimos gestionando tu pedido.'),
    tone: 'info',
  }
})

const statusSummaryLabel = computed(() => statusRawLabel.value || statusInfo.value.label)

const sellerName = computed(() => purchase.value?.motor?.author?.name || 'Vendedor')
const sellerAvatar = computed(() => {
  const avatar = purchase.value?.motor?.author?.acf?.avatar

  if (!avatar)
    return null

  if (typeof avatar === 'string')
    return avatar

  return avatar.url || null
})

const sellerInitials = computed(() => {
  const parts = sellerName.value.split(' ').filter(Boolean)

  return parts.slice(0, 2).map((part: string) => part[0]?.toUpperCase()).join('') || 'V'
})

const helpItems = [
  { id: 'contact', title: 'Como me pongo en contacto con el vendedor?' },
  { id: 'delivery', title: 'Necesito ayuda con envio y entrega' },
  { id: 'payment', title: 'Tengo preguntas sobre el pago' },
]

const sendOpinion = async () => {
  if (isSubmittingOpinion.value)
    return

  opinionError.value = null

  try {
    isSubmittingOpinion.value = true
    await useApi(`/wp-json/motorlan/v1/purchases/${uuid}/opinion`).post(opinion.value)
    opinionSuccess.value = true
    opinion.value = { rating: 0, comment: '' }
    setTimeout(() => {
      opinionSuccess.value = false
    }, 4000)
  }
  catch (error) {
    console.error(error)
    opinionError.value = 'No pudimos guardar tu opinion. Intenta de nuevo mas tarde.'
  }
  finally {
    isSubmittingOpinion.value = false
  }
}
</script>

<template>
  <VContainer
    v-if="isPurchaseLoading"
    class="purchase-page purchase-page__loading"
  >
    <div class="purchase-page__loading-indicator">
      <VProgressCircular
        color="primary"
        indeterminate
        size="32"
        width="3"
      />
    </div>
  </VContainer>

  <VContainer
    v-else-if="purchase"
    class="purchase-page"
  >
    <div class="px-6 pt-6 pb-4 bg-surface mb-6 rounded-lg elevation-1 d-flex align-center gap-2">
       <VBtn
          variant="text"
          color="medium-emphasis"
          size="small"
          :to="{ name: 'dashboard-purchases-purchases' }"
          prepend-icon="tabler-shopping-cart"
        >
          Compras
        </VBtn>
        <VIcon icon="tabler-chevron-right" size="14" color="medium-emphasis" />
        <span class="text-caption text-high-emphasis font-weight-bold text-uppercase tracking-wide">
          {{ productTitle || 'Detalle de Compra' }}
        </span>
    </div>

    <VRow
      class="purchase-layout"
      align="start"
      dense
    >
      <VCol
        cols="12"
        md="8"
        lg="9"
      >
        <div class="purchase-main">
          <VCard class="mb-6 rounded-xl overflow-hidden border" flat>
            <VCardText class="pa-0">
               <!-- Product Header Section -->
               <div class="pa-6 d-flex flex-column flex-md-row gap-6">
                  <!-- Product Image -->
                  <div class="flex-shrink-0">
                    <VAvatar
                      rounded="lg"
                      size="120"
                      color="surface-variant"
                      class="elevation-2"
                    >
                       <VImg
                          v-if="productImage"
                          :src="productImage"
                          cover
                        />
                        <VIcon v-else icon="tabler-photo-off" size="48" color="medium-emphasis" />
                    </VAvatar>
                  </div>

                  <!-- Product Info -->
                  <div class="flex-grow-1 min-w-0">
                     <div class="d-flex flex-wrap gap-2 mb-2">
                        <VChip
                           v-if="statusSummaryLabel"
                           size="small"
                           :color="statusInfo.tone"
                           variant="tonal"
                           class="font-weight-bold text-uppercase"
                           label
                        >
                           {{ statusSummaryLabel }}
                        </VChip>
                        <VChip
                           v-if="purchaseModeLabel"
                           size="small"
                           color="secondary"
                           variant="tonal"
                           class="font-weight-bold text-uppercase"
                           label
                        >
                           {{ purchaseModeLabel }}
                        </VChip>
                     </div>

                     <h1 class="text-h5 font-weight-bold text-high-emphasis mb-2 line-clamp-2">
                        <a 
                          v-if="productLink"
                          :href="productLink"
                          target="_blank"
                          class="text-high-emphasis text-decoration-none hover:text-primary transition-colors"
                        >
                          {{ productTitle }}
                        </a>
                        <span v-else>{{ productTitle }}</span>
                     </h1>

                     <div v-if="locationLabel" class="d-flex align-center gap-1 text-medium-emphasis text-body-2 mb-4">
                        <VIcon icon="tabler-map-pin" size="16" />
                        <span>{{ locationLabel }}</span>
                     </div>

                     <div class="d-flex align-end justify-space-between flex-wrap gap-4 mt-auto">
                        <div>
                           <div class="text-caption text-medium-emphasis text-uppercase font-weight-bold mb-1">{{ t('purchase_detail.total_to_pay') }}</div>
                           <div class="text-h4 font-weight-bold text-primary">
                              {{ totalPriceLabel }}
                           </div>
                           <div v-if="summaryPriceNotes.length" class="text-caption text-medium-emphasis mt-1">
                              {{ summaryPriceNotes.join(', ') }}
                           </div>
                        </div>

                         <div class="d-flex gap-3">
                             <VBtn
                                v-if="productLink"
                                :href="productLink"
                                target="_blank"
                                variant="tonal"
                                color="primary"
                                append-icon="tabler-external-link"
                              >
                                Ver Producto
                              </VBtn>
                         </div>
                     </div>
                  </div>
               </div>
            </VCardText>
          </VCard>

          <VCard class="mb-6 rounded-xl overflow-hidden border" flat>
             <VCardText class="pa-0 d-flex flex-column h-100">
               <div class="px-6 py-4 border-b bg-surface-variant-lighten d-flex align-center gap-2">
                  <VIcon icon="tabler-user-circle" color="primary" />
                  <h3 class="text-subtitle-1 font-weight-bold text-high-emphasis mb-0">{{ partyTitle }}</h3>
               </div>
               
               <div class="pa-6 d-flex flex-column flex-grow-1">
                 <div class="d-flex align-center mb-6">
                    <VAvatar
                      :image="partyAvatar || undefined"
                      :color="partyAvatar ? undefined : 'primary-lighten-4'"
                      variant="elevated"
                      size="64"
                      class="mr-4 elevation-2"
                    >
                      <span v-if="!partyAvatar" class="text-h5 font-weight-bold text-primary">{{ partyInitials }}</span>
                    </VAvatar>
                    
                    <div class="min-w-0">
                       <div class="text-h6 font-weight-bold text-high-emphasis text-truncate mb-1">
                          {{ partyName }}
                       </div>
                       <div v-if="sellerCompany" class="text-body-2 text-medium-emphasis d-flex align-center gap-1 mb-1">
                          <VIcon icon="tabler-building-skyscraper" size="14" />
                          <span>{{ sellerCompany }}</span>
                       </div>
                       <div v-if="locationLabel" class="text-body-2 text-medium-emphasis d-flex align-center gap-1">
                          <VIcon icon="tabler-map-pin" size="14" />
                          <span>{{ locationLabel }}</span>
                       </div>
                    </div>
                 </div>

                 <!-- Metrics -->
                 <div v-if="hasSellerMetrics" class="d-flex gap-4 mb-6">
                    <div v-if="sellerRating !== null" class="d-flex align-center gap-1 bg-surface-variant px-3 py-1 rounded-pill">
                       <VRating
                          :model-value="sellerRating"
                          color="warning"
                          density="compact"
                          half-increments
                          readonly
                          size="16"
                        />
                        <span class="text-caption font-weight-bold">{{ sellerRatingLabel }}</span>
                    </div>
                     <div v-if="sellerSalesText" class="d-flex align-center gap-1 bg-surface-variant px-3 py-1 rounded-pill">
                       <VIcon icon="tabler-shopping-bag" size="14" color="medium-emphasis" />
                       <span class="text-caption font-weight-bold">{{ sellerSalesText }}</span>
                    </div>
                 </div>

                 <!-- Contact -->
                 <div v-if="partyHasContact" class="mb-6">
                    <a v-if="partyEmail" :href="`mailto:${partyEmail}`" class="d-flex align-center gap-2 text-decoration-none text-body-2 text-high-emphasis px-3 py-2 rounded hover:bg-surface-variant transition-colors">
                       <div class="v-avatar v-theme--light v-avatar--density-default v-avatar--variant-tonal v-avatar--rounded" style="width: 32px; height: 32px;">
                          <VIcon icon="tabler-mail" size="18" color="primary" />
                       </div>
                       <span>{{ partyEmail }}</span>
                    </a>
                 </div>

                 <div class="mt-auto pt-4 border-t d-flex gap-3">
                    <VBtn
                      block
                      color="primary"
                      size="large"
                      height="48"
                      prepend-icon="tabler-message-circle" 
                      class="flex-grow-1 font-weight-bold shadow-primary"
                      @click="openChat"
                    >
                      Abrir chat
                    </VBtn>
                    
                    <VBtn
                      v-if="productLink"
                      :href="productLink"
                      target="_blank"
                      variant="tonal"
                      color="secondary"
                      icon="tabler-external-link"
                      size="large"
                      class="rounded-lg"
                    />
                 </div>
               </div>
             </VCardText>
          </VCard>

          <VCard class="mb-6 rounded-xl overflow-hidden border" flat>
            <VCardText class="pa-6 text-center" :class="`bg-${statusInfo.tone}-lighten-5`">
              <VAvatar
                 :color="statusInfo.tone"
                 variant="tonal"
                 size="64"
                 class="mb-4"
              >
                 <VIcon icon="tabler-info-circle" size="32" />
              </VAvatar>
              
              <h2 class="text-h5 font-weight-bold text-high-emphasis mb-2">
                {{ statusInfo.title }}
              </h2>
              
              <div class="d-flex justify-center mb-4">
                 <VChip
                    :color="statusInfo.tone"
                    label
                    class="font-weight-bold"
                 >
                    {{ statusInfo.label }}
                 </VChip>
              </div>
              
              <p class="text-body-1 text-medium-emphasis max-w-sm mx-auto mb-0">
                {{ statusInfo.description }}
              </p>
              
              <div v-if="statusRawLabel" class="text-caption text-disabled mt-2">
                 Estado técnico: {{ statusRawLabel }}
              </div>
            </VCardText>
          </VCard>


          <VCard
            v-if="hasOffer"
            class="purchase-card offer-card"
          >
            <VCardTitle>{{ t('purchase_detail.price_offer') }}</VCardTitle>
            <VCardText>
              <div class="offer-card__header">
                <div class="offer-card__amount">
                  {{ offerAmountLabel || totalPriceLabel }}
                </div>
                <VChip
                  v-if="offerStatusInfo"
                  :color="offerStatusInfo.color"
                  size="small"
                  label
                  class="offer-card__status"
                >
                  {{ offerStatusInfo.label }}
                </VChip>
              </div>
              <p
                v-if="offerStatusInfo && offerStatusInfo.description"
                class="offer-card__description"
              >
                {{ offerStatusInfo.description }}
              </p>
              <div class="offer-card__meta">
                <div
                  v-if="offerDateLabel"
                  class="offer-card__meta-item"
                >
                  <span class="offer-card__meta-label">{{ t('purchase_detail.sent') }}</span>
                  <span class="offer-card__meta-value">{{ offerDateLabel }}</span>
                </div>
                <div
                  v-if="offerAcceptedLabel"
                  class="offer-card__meta-item"
                >
                  <span class="offer-card__meta-label">{{ t('purchase_detail.accepted') }}</span>
                  <span class="offer-card__meta-value">{{ offerAcceptedLabel }}</span>
                </div>
                <div
                  v-if="offerConfirmedLabel"
                  class="offer-card__meta-item"
                >
                  <span class="offer-card__meta-label">{{ t('purchase_detail.confirmed') }}</span>
                  <span class="offer-card__meta-value">{{ offerConfirmedLabel }}</span>
                </div>
                <div
                  v-if="offerExpiresLabel && !offerConfirmedLabel"
                  class="offer-card__meta-item"
                >
                  <span class="offer-card__meta-label">{{ t('purchase_detail.expires') }}</span>
                  <span class="offer-card__meta-value">{{ offerExpiresLabel }}</span>
                </div>
              </div>
              <div
                v-if="offerJustification"
                class="offer-card__justification"
              >
                <span class="offer-card__justification-label">{{ t('purchase_detail.message_sent') }}</span>
                <p class="offer-card__justification-text">
                  {{ offerJustification }}
                </p>
              </div>
            </VCardText>
          </VCard>

          <!-- Sección de Ayuda y Mensajes eliminada por solicitud -->

          <!-- Rating CTA Card (If not rated yet and purchase is completed/delivered mechanism exists, or always show for now as requested) -->
          <VCard 
            v-if="!purchase?.review_done && viewerRole === 'buyer'"
            class="purchase-card rating-card mb-6"
          >
             <VCardText class="d-flex flex-column flex-sm-row align-center justify-space-between gap-4 pa-6">
                 <div>
                    <h3 class="text-h6 font-weight-bold mb-1">¿Qué tal tu experiencia?</h3>
                    <p class="text-body-2 text-medium-emphasis mb-0">{{ t('purchase_detail.rate_seller_hint') }}</p>
                 </div>
                 <VBtn
                    color="warning"
                    prepend-icon="tabler-star"
                    @click="showRatingModal = true"
                 >
                    Valorar Vendedor
                 </VBtn>
             </VCardText>
          </VCard>
        </div>
      </VCol>

      <VCol
        cols="12"
        md="4"
        lg="3"
      >
        <VCard class="purchase-card summary-panel motor-card-enhanced">
          <VCardTitle class="pa-6 pb-0">
            <span class="text-h6 text-premium-title">{{ t('purchase_detail.purchase_detail_title') }}</span>
          </VCardTitle>
          <VCardText>
            <div class="summary-panel__date">
              {{ purchase.fecha_compra }}
            </div>
            <div
              v-if="purchase.uuid"
              class="summary-panel__id"
            >
              # {{ purchase.uuid }}
            </div>
            <div
              v-if="statusSummaryLabel"
              class="summary-panel__row"
            >
              <span>{{ t('purchase_detail.status') }}</span>
              <span>{{ statusSummaryLabel }}</span>
            </div>
            <div
              v-if="purchaseModeLabel"
              class="summary-panel__row"
            >
              <span>{{ t('purchase_detail.purchase_type') }}</span>
              <span>{{ purchaseModeLabel }}</span>
            </div>
            <div class="summary-panel__row summary-panel__row--stack">
              <span class="summary-panel__label">{{ t('purchase_detail.product') }}</span>
              <span class="summary-panel__value">{{ productTitle }}</span>
            </div>
            <div
              v-if="productTypeLabel"
              class="summary-panel__row summary-panel__row--stack"
            >
              <span class="summary-panel__label">{{ t('purchase_detail.type') }}</span>
              <span class="summary-panel__value">{{ productTypeLabel }}</span>
            </div>
            <div class="summary-panel__row">
              <span>{{ t('purchase_detail.quantity') }}</span>
              <span>{{ quantityLabel }}</span>
            </div>
            <div
              v-if="unitPriceValue !== null"
              class="summary-panel__row"
            >
              <span>{{ t('purchase_detail.unit_price') }}</span>
              <span>{{ unitPriceLabel }}</span>
            </div>
            <div
              v-if="publishedPriceLabel"
              class="summary-panel__row"
            >
              <span>{{ t('purchase_detail.published_price') }}</span>
              <span>{{ publishedPriceLabel }}</span>
            </div>
            <div
              v-if="hasOffer && offerAmountLabel"
              class="summary-panel__row"
            >
              <span>{{ t('purchase_detail.accepted_offer') }}</span>
              <span>{{ offerAmountLabel }}</span>
            </div>
            <div class="summary-panel__row summary-panel__row--total">
              <span>{{ t('purchase_detail.total_paid') }}</span>
              <span>{{ totalPriceLabel }}</span>
            </div>

            <VExpansionPanels
              class="summary-panel__details"
              variant="accordion"
            >
              <VExpansionPanel :title="t('purchase_detail.payment_delivery_details')">
                <VExpansionPanelText>
                  <p class="summary-panel__details-text">
                    Coordina directamente con el vendedor la fecha y el lugar de entrega.
                  </p>
                </VExpansionPanelText>
              </VExpansionPanel>
            </VExpansionPanels>
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </VContainer>

  <!-- Chat Modal -->
  <ChatModal
    v-if="uuid"
    v-model:is-open="isChatModalOpen"
    :purchase-uuid="uuid"
    context-type="purchase"
    :publication-title="productTitle"
    :publication-image="productImage"
  />
  
  <RatingModal
    v-if="showRatingModal"
    v-model="showRatingModal"
    :purchase-uuid="uuid"
    target-role="seller"
    :target-name="partyName"
    @success="handleRatingSuccess"
  />

  <VContainer
    v-else
    class="purchase-page__empty"
  >
    <VCard class="pa-8 text-center mx-auto empty-card">
      <VCardTitle class="justify-center">
        {{ purchaseError || 'No encontramos la compra' }}
      </VCardTitle>
      <VCardText>
        Revisa el enlace o vuelve a la tienda para continuar navegando.
      </VCardText>
      <VCardActions class="justify-center">
        <VBtn
          color="primary"
          :to="{ path: '/' }"
        >
          Ir a la tienda
        </VBtn>
      </VCardActions>
    </VCard>
    <!-- Chat Modal -->
    <ChatModal
      v-if="purchase?.uuid"
      v-model:is-open="isChatModalOpen"
      :purchase-uuid="purchase.uuid"
      context-type="purchase"
      :publication-title="productTitle"
      :publication-image="productImage"
    />
  </VContainer>
</template>

<style scoped lang="scss">
.purchase-page {
  padding: 32px 0 48px;
  min-height: 100%;
}

.purchase-breadcrumbs {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 16px;
  margin-bottom: 24px;
  font-size: 0.875rem;
  color: #6c7592;

  &__link {
    color: inherit;
    text-decoration: none;
    font-weight: 500;

    &:hover {
      text-decoration: underline;
    }
  }

  &__current {
    color: #1f2233;
    font-weight: 600;
  }
}

.purchase-layout {
  margin: 0;
}

.purchase-main {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.purchase-card {
  border-radius: 14px;
  box-shadow: 0 12px 30px rgba(36, 50, 87, 0.08);
  border: 1px solid #e3e7ef;
}

.summary-card {
  .summary-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
  }

  .summary-info {
    flex: 1;
  }

  .summary-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #1f2233;
    margin-bottom: 4px;
  }

  .summary-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.875rem;
    color: #6c7592;
  }

  .summary-link {
    color: rgb(var(--v-theme-primary));
    text-decoration: none;
    font-weight: 600;

    &:hover {
      text-decoration: underline;
    }
  }

  .summary-title__link {
    color: inherit;
    text-decoration: none;
  }

  .summary-title__link:hover {
    text-decoration: underline;
  }

  .summary-location {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 8px;
    font-size: 0.875rem;
    color: #6c7592;
  }

  .summary-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 12px;
  }

  .summary-tag {
    display: inline-flex;
    align-items: center;
    padding: 4px 12px;
    border-radius: 999px;
    background: #eef1f6;
    color: #515b75;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  .summary-tag--highlight {
    background: rgba(var(--v-theme-primary), 0.16);
    color: rgb(var(--v-theme-primary));
  }

  .summary-price {
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-top: 16px;
  }

  .summary-price__label {
    font-size: 0.75rem;
    color: #6c7592;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    font-weight: 600;
  }

  .summary-price__value {
    font-size: 1.1rem;
    font-weight: 700;
    color: #1f2233;
  }

  .summary-price__note {
    display: block;
    margin-top: 2px;
    font-size: 0.8rem;
    color: #6c7592;
  }

  .summary-avatar {
    background: #f0f2f8;
    color: #9aa0b5;

    &--placeholder {
      font-size: 0;
    }
  }
}

.status-card {
  padding-bottom: 4px;

  .status-chip {
    display: inline-flex;
    align-items: center;
    padding: 6px 14px;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 700;
    margin-bottom: 16px;

    &--success {
      background: #e6f7f0;
      color: #137750;
    }

    &--warning {
      background: #fff4db;
      color: #b76b00;
    }

    &--info {
      background: #e4f0ff;
      color: #1c4fb8;
    }

    &--error {
      background: #ffe1e1;
      color: #c42626;
    }
  }

  .status-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #1f2233;
    margin-bottom: 8px;
  }

  .status-description {
    margin: 0;
    color: #515b75;
    font-size: 0.95rem;
  }

  .status-description--muted {
    margin-top: 8px;
    color: #6c7592;
  }

  .status-actions {
    margin-top: 20px;
  }
}

.seller-card {
  .seller-card__header {
    display: flex;
    align-items: center;
  }

  .seller-card__identity {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .seller-card__name {
    font-weight: 600;
    font-size: 1rem;
    color: #1f2233;
  }

  .seller-card__company {
    font-size: 0.875rem;
    color: #515b75;
  }

  .seller-card__location {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.85rem;
    color: #6c7592;
  }

  .seller-card__metrics {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 16px;
    font-size: 0.875rem;
    color: #1f2233;
  }

  .seller-card__metrics-item {
    display: inline-flex;
    align-items: center;
  }

  .seller-card__contact {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-top: 16px;
    font-size: 0.875rem;
  }

  .seller-card__contact-item {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #1f2233;
    text-decoration: none;
  }

  .seller-card__contact-item:hover {
    text-decoration: underline;
  }

  .seller-card__actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 20px;
  }

  .avatar-initials {
    font-weight: 600;
    color: #fff;
  }
}

.offer-card {
  .offer-card__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .offer-card__amount {
    font-size: 1.25rem;
    font-weight: 700;
    color: #1f2233;
  }

  .offer-card__status {
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 600;
  }

  .offer-card__description {
    margin: 12px 0 0;
    color: #515b75;
    font-size: 0.9rem;
  }

  .offer-card__meta {
    display: grid;
    gap: 12px;
    margin-top: 16px;
  }

  @media (min-width: 600px) {
    .offer-card__meta {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  .offer-card__meta-item {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .offer-card__meta-label {
    font-size: 0.75rem;
    text-transform: uppercase;
    color: #6c7592;
    letter-spacing: 0.05em;
    font-weight: 600;
  }

  .offer-card__meta-value {
    font-size: 0.95rem;
    color: #1f2233;
  }

  .offer-card__justification {
    margin-top: 20px;
    padding: 16px;
    border-radius: 12px;
    background: #f5f7fb;
  }

  .offer-card__justification-label {
    font-size: 0.75rem;
    text-transform: uppercase;
    color: #6c7592;
    letter-spacing: 0.05em;
    font-weight: 600;
  }

  .offer-card__justification-text {
    margin: 8px 0 0;
    color: #1f2233;
    font-size: 0.95rem;
  }
}

.opinion-card {
  .v-card-title {
    font-weight: 600;
  }

  .v-rating__wrapper {
    justify-content: flex-start;
  }
}

.help-card {
  .help-item {
    border-top: 1px solid #eef1f6;
    cursor: pointer;

    &:first-of-type {
      border-top: none;
    }
  }
}

.messages-card {
  .messages-item {
    border-top: 1px solid #eef1f6;
    cursor: pointer;
  }

  .avatar-initials {
    font-weight: 600;
    color: #fff;
  }
}

.summary-panel {
  position: sticky;
  top: 80px;
  background: #fdfdfd;

  .summary-panel__date {
    font-size: 0.875rem;
    color: #6c7592;
  }

  .summary-panel__id {
    font-size: 0.875rem;
    color: #6c7592;
    margin-bottom: 16px;
  }

  .summary-panel__row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    font-size: 0.95rem;
    color: #1f2233;
  }

  .summary-panel__row--stack {
    flex-direction: column;
    align-items: flex-start;
    gap: 4px;
  }

  .summary-panel__label {
    font-size: 0.75rem;
    text-transform: uppercase;
    color: #6c7592;
    letter-spacing: 0.05em;
    font-weight: 600;
  }

  .summary-panel__value {
    font-size: 0.95rem;
    color: #1f2233;
    word-break: break-word;
  }

  .summary-panel__row--total {
    font-weight: 700;
    font-size: 1.05rem;
  }

  .summary-panel__details {
    margin-top: 16px;
    border-radius: 12px;
    border: 1px solid #e3e7ef;

    .summary-panel__details-text {
      margin: 0;
      color: #515b75;
      font-size: 0.9rem;
    }
  }
}

.purchase-page__empty {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(100vh - 160px);
}

.purchase-page__loading {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(100vh - 160px);
}

.purchase-page__loading-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 160px;
  width: 100%;
}

.empty-card {
  max-width: 420px;
}

@media (max-width: 960px) {
  .purchase-page {
    padding: 24px 0 36px;
  }

  .purchase-breadcrumbs {
    margin-bottom: 16px;
  }

  .summary-panel {
    position: static;
  }

  .summary-panel :deep(.v-card-text),
  .rating-card :deep(.v-card-text),
  .offer-card :deep(.v-card-text) {
    padding-inline: 1rem;
  }

  .summary-panel__row {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.25rem;
  }

  .summary-panel__row--total {
    align-items: flex-start;
  }

  .purchase-card .d-flex.flex-column.flex-sm-row.align-center.justify-space-between {
    flex-direction: column;
    align-items: flex-start;
  }

  .purchase-card .d-flex.flex-column.flex-sm-row.align-center.justify-space-between .v-btn {
    width: 100%;
  }

  .offer-card__header,
  .seller-card__header {
    flex-direction: column;
    align-items: flex-start;
  }

  .offer-card__meta {
    grid-template-columns: 1fr;
  }

  .seller-card__actions,
  .seller-card__metrics,
  .summary-tags {
    gap: 8px;
  }

  .purchase-card :deep(.v-card-title),
  .purchase-card :deep(.v-card-actions) {
    padding-inline: 1rem;
  }

  .purchase-card :deep(.v-btn) {
    width: 100%;
  }
}
</style>
